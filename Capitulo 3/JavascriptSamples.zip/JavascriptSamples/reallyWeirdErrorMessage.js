export default {
  type: 'danger',
  message:
    'Something really weird happened, if it happens again, please consider ' +
    "raising an issue on <a href='https://github.com/freeCodeCamp" +
    "/freeCodeCamp/issues/new' target='_blank' rel='nofollow " +
    "noreferrer'>GitHub</a>."
};

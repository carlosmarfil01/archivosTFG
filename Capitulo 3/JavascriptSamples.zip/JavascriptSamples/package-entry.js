export { default as getChallenges } from './getChallenges';

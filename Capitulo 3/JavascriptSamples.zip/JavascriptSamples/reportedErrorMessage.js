export default {
  type: 'danger',
  message:
    'Something is not quite right. A report has been generated and the ' +
    'freeCodeCamp.org team have been notified.'
};

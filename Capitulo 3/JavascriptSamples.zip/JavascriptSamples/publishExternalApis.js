'use strict';

publishExternalAPI(angular);

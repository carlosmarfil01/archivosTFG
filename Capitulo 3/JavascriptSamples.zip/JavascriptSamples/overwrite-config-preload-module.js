'use strict'
const common = require('../common');
common.skipIfInspectorDisabled();

process.config = {};

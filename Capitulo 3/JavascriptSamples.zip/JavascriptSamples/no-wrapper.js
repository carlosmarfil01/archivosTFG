require('module').wrapper = ['', ''];
